create function nomtrigger() returns trigger
    language plpgsql
as
$$
declare nom_var integer ;
    begin --utiliser RAISE EXCEPTION ‘texte’ pour une levée d’exception --utiliser new et old pour des triggers lignes
    raise notice 'Un nouveau projet est créé';
    return new;
    End;
$$;

alter function nomtrigger() owner to postgres;

