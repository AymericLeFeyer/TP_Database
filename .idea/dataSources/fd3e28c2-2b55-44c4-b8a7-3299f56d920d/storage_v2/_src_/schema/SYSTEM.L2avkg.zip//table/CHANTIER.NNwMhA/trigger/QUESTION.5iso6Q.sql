create trigger QUESTION
    after insert
    on CHANTIER
    for each row
BEGIN
    UPDATE PROJET
        SET PROJET.MONTANT = 50000
    WHERE PROJET.IDPROJET=NEW.IDPROJET;

END;
/

